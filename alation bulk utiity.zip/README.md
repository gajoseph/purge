[[_TOC_]]

# Alation Asset Loader
A Python project to bulk load assets into Alation.

## Guide to Setting Up on Your System

1. **Installation Process**
   - Install Git if needed:
     - [Git Download](https://git-scm.com/downloads)
   - Install Python:
     - [Python Download](https://www.python.org/downloads/)
   - Clone the repository to your environment.
   - Follow the steps in [`py.bash`](py.bash) to set up the Python virtual environment and install dependencies.

2. **Software Dependencies**
   - Python

3. **Alation API References**
   - [Alation API Documentation](https://developer.alation.com/dev/reference/)

### Set Up a Virtual Environment:

<details>
<blockquote> 
1. Install `virtualenv` (if not already installed):
    ```bash
    pip install virtualenv
    ```

2. Create a Virtual Environment:
    ```bash
    virtualenv venv
    ```

3. Activate the Virtual Environment:
    ```bash
    .env\Scriptsctivate
    ```

4. Install the required packages:
    ```bash
    pip install -r requirements.txt
    ```

[Python Virtual Environment Documentation](https://docs.python.org/3/library/venv.html)
</blockquote>
</details>

Follow the steps in [bulk loader](bulk_loader.md) to run the program.
