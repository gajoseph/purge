import  common.propertyreader as pr 
from os import environ
import os 
import common.utils as ut 
import alation.table as tb
import common.file_processing as fp 
import re
import json 

def set_payload_table( retrivied_keys:list, tab_info:dict, from_ds_id, to_ds_id):
    pyload_keys = ['key', 'title', 'description', 'table_comment', 'table_type', 'table_type_name', 'owner', 'sql', 'base_table_key', 'partition_definition', 'partition_columns']
    payload= {}
    for key in pyload_keys:
        if key in retrivied_keys:
            if tab_info[key]:
                if key == "key":
                   
                    payload[key] =  tab_info[key].replace(str(from_ds_id), str(to_ds_id))
                else:
                    payload[key] = tab_info[key]

    return payload



def set_payload_column( columns_info:dict, from_ds_id, to_ds_id):
    pyload_keys = ['key', 'column_type', 'title', 'description', 'column_comment','nullable', 'position', 'index'] # need to fix custom field
    retrivied_keys = ['id', 'name', 'title', 'description', 'ds_id', 'key', 'url', 'custom_fields', 'column_type', 'column_comment', 'index', 'nullable', 'schema_id', 'table_id', 'table_name', 'position']
    column_pay_load=[]
    for col in columns_info:
        column_pay_load.append( set_payload(pyload_keys, retrivied_keys, obj_info = col, from_ds_id = from_ds_id, to_ds_id = to_ds_id))
    return column_pay_load

def set_payload(pyload_keys, retrivied_keys, obj_info:dict, from_ds_id, to_ds_id):

    payload= {}
    for key in pyload_keys:
        if key in retrivied_keys:
            if key =='referencedColumnId':
                print(key)
            if obj_info[key] and obj_info[key] != "null":
                if key == "key":
                   
                    payload[key] =  obj_info[key].replace(str(from_ds_id), str(to_ds_id))
                elif key =='index':
                    new_index_dict = obj_info[key]
                    if new_index_dict.get('referencedColumnId') is None:
                        del new_index_dict['referencedColumnId']
                        print(new_index_dict)
                        payload[key] = new_index_dict
                elif key == 'custom_key':
                    if len(obj_info['custom_fields']):
                        payload[key] = obj_info[key]
                else:
                    payload[key] = obj_info[key]
            elif key =='title':
                if 'name' in retrivied_keys:
                    name_title = obj_info['name'] 
                    name_to_title = re.sub(r'([a-z])([A-Z])', r'\1 \2', name_title)
                    payload[key] = name_to_title
            
            
            

    return payload

                   


config = pr.get_yaml_properties(environ['ENV_YAML_PATH'])
__prop_dict = config
ut.setLoggingInfo(__prop_dict)

import logging 
logger = logging.getLogger(__name__)
logger.info("George")


table_obj = tb.table()

al_tabs = table_obj.gettables(8) # get all the tables in data source aka from source 
# print(al_tabs)
from_ds_id=8
to_ds_id=11
# with open("output.txt", "w") as file:
for tab in al_tabs:
    values=""
    
    table_props = ['id', 'name', 'title', 'description', 'ds_id', 'key', 'url', 'custom_fields', 'table_type', 'schema_id', 'schema_name', 'base_table_key', 'sql', 'partition_columns', 'partition_definition', 'table_comment']
    # print(tab["name"])
    
    if tab["name"].strip().lower() == 'ZIPtoFIPS'.lower():
        print(tab["name"])
        for prop in table_props:
            values += f"{prop}= {tab[prop]}\t"    
        pay_load = set_payload_table(table_props, tab, from_ds_id, to_ds_id)
        """
        Get the table nae from soure DS
        Load the data to destination DS

        Get columns from source DS
        lod the columns to destination DS

        """
        print("--------------------------------------------------------------------------------------------------------------------------------")
        print(values)
        print(pay_load)
        # create the table in destination 
        response = table_obj.load_tabs( ds_id = to_ds_id, payload= [pay_load])
        print(response)
        if response:
            
                if response['status']=='successful':
                    table_obj.logger.info(response)


                    tab_cols = table_obj.getcolumns(ds_id = from_ds_id, table_id = tab[table_props[0]])
                    
                    tab_cols_payload = set_payload_column(tab_cols, from_ds_id, to_ds_id)
                    print(">>\n", tab_cols_payload)
                    res = table_obj.create_columns(ds_id = to_ds_id, table_id =tab[table_props[0]], payload=tab_cols_payload )
                    print(res)

                    print(tab_cols_payload)

import csv

# Define the properties to be included in the CSV
table_props = ['id', 'name', 'title', 'description', 'ds_id']
# Add a new column for tab_cols
table_props.append('columns')

# Open a CSV file to write the output
with open("output_with_columns.csv", mode="w", newline="") as file:
    writer = csv.DictWriter(file, fieldnames=table_props)

    # Write the header
    writer.writeheader()

    # Iterate through each tab in al_tabs
    for tab in al_tabs:
        # Check if the description is not empty
    
        # Retrieve the columns using getcolumns method
        tab_cols = table_obj.getcolumns(ds_id=from_ds_id, table_id=tab[table_props[0]])

        pyload_keys = ['key', 'column_type', 'title', 'description'] # need to fix custom field
        retrivied_keys = ['id', 'name', 'title', 'description', 'ds_id', 'key', 'url', 'custom_fields', 'column_type', 'column_comment', 'index', 'nullable', 'schema_id', 'table_id', 'table_name', 'position']
        column_pay_load=[]
        print(print(tab["name"]), " NAME")
        row_data = {prop: tab.get(prop, "") for prop in table_props if prop != 'columns'}
        col_wrote =False 
        for col in tab_cols:
            if col["description"]!='':
                col_wrote=True
                # Convert tab_cols to a string representation (e.g., comma-separated list)
                # tab_cols_str = ', '.join(column_pay_load) if tab_cols else ""

                # Prepare the row data
                
                row_data['columns'] = ','.join([col['key'], col['description'] ])
                
                # Write the row to the CSV file
                writer.writerow(row_data)

        if not col_wrote:
            if tab.get("description", "").strip():
                writer.writerow(row_data)


    
