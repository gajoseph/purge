import logging
from alation.api_client import APIClient  # Import the APIClient class

class InvalidDataStructureError(Exception):
    def __init__(self, message, data_item):
        super().__init__(message)
        self.data_item = data_item

    def __str__(self):
        return f"{self.message}: {self.data_item}"


class DocumentClient(APIClient):
    def __init__(self):
        super().__init__()
        self.url = "/integration/v2/document/"
        self.document_details = {}
        self.document_title =''
        self.document_description = ''
        self.template_id= 0
        self.folder_ids = []
        self.id = 0
        self.document_hub_id = 0

    def validate_payload_structure(self, data_item):
        required_structure = {
        "title": str,
        "document_hub_id": int,
        "description": str,
        "template_id": int,
        "folder_ids": list
    }
    
        for key, expected_type in required_structure.items():
            if key not in data_item:
                print(key)
                return False
            # if not isinstance(data_item[key], expected_type):
            #     print(key, expected_type)
            #     return False
        
        return True

    def __set_properties(self, document_title=None, document_description=None, template_id=None, folder_ids=[], document_hub_id = 0):
        self.document_title = document_title if document_title is not None else None
        self.document_description = document_description if document_description is not None else None
        self.template_id = template_id if template_id is not None else None
        self.folder_ids = [folder_ids] if folder_ids is not None else []
        self.document_hub_id = document_hub_id
        

    def __build_payload(self):
        return [
            {
                "title": self.document_title,
                "document_hub_id": self.document_hub_id,
                "description": self.document_description,
                "template_id": self.template_id,
                "folder_ids": self.folder_ids
            }
        ]
    
    def __build_put_payload(self):
        payload = self.__build_payload()
        payload[0]['id'] = self.id
        return payload
    
    def get_job_status(self):
        job_id = self.document_details['job_id']
        job_status_rep = self.send_get_job_status(url = "/api/v1/bulk_metadata/job/", payload= {"id":job_id})
        if "created_terms" in job_status_rep['result']:
            self.id = job_status_rep['result'].get("created_terms" )[0].get("id")
        elif  "updated_terms" in job_status_rep['result']:
            self.id = job_status_rep['result'].get("updated_terms" )[0].get("id")
        return job_status_rep
        
    

    def create_documents(self, pay_load_data: list ):
        for data_item in pay_load_data:
            if self.validate_payload_structure(data_item):
                print(f"Valid data item: {data_item}")
                self.logger.info(f"Valid data item: {data_item}")
            else:
                print(f"Invalid data item: {data_item}")
                self.logger.error(f"Invalid data item: {data_item}")
                raise InvalidDataStructureError("Invalid data item", data_item) 
           
        response = self.send_post_request(url = self.url, payload= pay_load_data, verify=False)
         # Check the response
        if response and response.status_code == 202:
            
            self.document_details = response.json()
            self.logger.info(f'Documents Created:{self.document_details}')
            
            job_id = self.document_details['job_id']
            return job_id
        else:
            print('Failed:', response.status_code, response.text)
            return None

    def create_document(self, document_title, document_description, template_id, folder_ids, document_hub_id):
        self.__set_properties(document_title, document_description, template_id, folder_ids, document_hub_id)
        payload = self.__build_payload()
        
        
        response = self.send_post_request(url = self.url, payload= payload, verify=False)
        
        # Check the response
        if response and response.status_code == 202:
            
            self.document_details = response.json()
            self.logger.info(f'Documents Created:{self.document_details}')
            return self.get_job_status()
            
            
        else:
            print('Failed:', response.status_code, response.text)
            return None
        

    def update_document(self, document_title= None, document_description= None, template_id= None, folder_ids = None, overwrite= False, document_hub_id= 0):
        self.__set_properties( document_title, document_description, template_id, folder_ids, document_hub_id)
        payload = self.__build_put_payload()

        if not overwrite:
            return self.build_skipped_overwite(payload=payload)

        try:
        
            response = self.send_put_request(url = self.url, payload= payload, verify=False)
            # Check the response
            if response and response.status_code == 202:
                
                self.document_details = response.json()
                self.logger.info(f'Documents updated:{self.document_details}')
                
                return self.get_job_status()
            else:
                print('Failed:', response.status_code, response.text)
                return None
        except Exception as err:
            self.logger.error(f"An unexpected error occurred: {err}")  # Handle any other exceptions

    def search_documents(self, searh_str_anyfield:str, document_hub_id = None, template_id = None, folder_id= None):
        payload = {}
        self.document_details ={}
        self.__set_properties()
        try:
            
            if folder_id is not None:
                payload['folder_id'] = folder_id
            if document_hub_id is not None:
                payload['document_hub_id'] = document_hub_id
            
            # if limit is not None:
            #     payload['limit'] = limit
            # if skip is not None:
            #     payload['skip'] = skip
            if searh_str_anyfield:
                payload['search'] = searh_str_anyfield
            # if deleted is not None:
            #     payload['deleted'] = str(deleted).lower()
            response = self.send_get_request(self.url,  payload=payload, verify=False)
            if response: 
                
                if response.status_code == 200:
                    self.logger.info(f"Documents exists: {response}")
                    # Get the Job ID from the response
                    
                    self.document_details = response.json()
                    
                    self.document_title = self.document_details[0]['title']
                    self.document_description = self.document_details[0]['description']
                    self.template_id = self.document_details[0]['template_id']
                    self.folder_ids = self.document_details[0]['folder_ids']
                    self.id = self.document_details[0]['id']
                
                    self.logger.debug(f"document_details: length= {len(self.document_details)}")
                
                        

            else:
                print('Failed:')
                return None
        except Exception as err: 
            self.logger.error(f"Error when processing {payload} {str(err)}")


    def delete_document(self,doc_ids: list ):
        repsone = self.send_del_request(self.url, payload={"id":doc_ids}, verify = False)
        print(repsone)
        if repsone.status_code == 200:
            if repsone:
                return repsone.json()
                job_id = self.document_details['job_id']
                return self.send_get_job_status(url = "/api/v1/bulk_metadata/job/", payload= {"id":job_id})
            
        else:
            return None

        pass

# Example usage
if __name__ == "__main__":
       
    # Initialize DocumentClient
    client = DocumentClient()
    
    # Example document details
    document_title = "Sample Document"
    document_description = "This is a sample document."
    template_id = 63
    folder_ids = [19]
    
    # Create document
    # job_id = client.create_document(document_title, document_description, template_id, folder_ids)
    client.search_documents(document_title, document_hub_id=6 )
    if len(client.document_details) ==1: 
        client.logger.info("Foudn one")

    # if job_id:
    #     print(f"Document creation job started with ID: {job_id}")
    # else:
    #     print("Document creation failed.")
