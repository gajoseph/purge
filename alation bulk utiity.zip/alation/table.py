import logging

from alation.api_client import APIClient 

class table(APIClient):
    def __init__(self):
        super().__init__()
        self.url = "/integration/v2/table/"
        self.document_details = {}
        self.document_title =''
        self.document_description = ''
        self.template_id= 0
        self.folder_ids = []
        self.id = 0
        self.ds_id =0

    def gettables(self, ds_id):
        self.ds_id = ds_id
        payload = {}
        payload['ds_id'] = self.ds_id
        payload['limit'] = 200 # pass as param later 
        # integration/v2/table/?ds_id=11
        response = self.send_get_request(url = self.url,  payload=payload, verify=False)
        if response.status_code == 200:
            # print(response.text)
            return response.json()
        
        else:
            return None
        

    def load_tabs(self, ds_id, payload:dict):

        response = self.send_post_request(url = self.url+ f"?ds_id={ds_id}",  payload=payload, verify=False)
        if response.status_code == 202:
            # print(response.text)
            response.json()
            return self.send_get_job_status(url = "/api/v1/bulk_metadata/job/", payload= {"id":response.json()["job_id"]})
        
        else:
            return None
        

    def getcolumns(self, ds_id, table_id):
        self.ds_id = ds_id
        self.id = table_id
        payload = {}
        payload['ds_id'] = self.ds_id
        payload['table_id'] = self.id
        payload['order_by'] = "id"
        response = self.send_get_request(url =  f"/integration/v2/column/",  payload=payload, verify=False)
        if response.status_code == 200:
            # print(response.text)
            return response.json()
            
        
        else:
            return None
        

    def create_columns(self, ds_id, table_id, payload:list):
        self.ds_id = ds_id
        self.id = table_id
     
        response = self.send_post_request(url = "/integration/v2/column/"+ f"?ds_id={ds_id}",  payload=payload, verify=False)
        if response.status_code == 202:
            # print(response.text)
            response.json()
            return self.send_get_job_status(url = "/api/v1/bulk_metadata/job/", payload= {"id":response.json()["job_id"]})
        
        else:
            return None

    def send_get_job_status(self, url:str, payload:dict, headers: dict = None, verify: bool = False ):
        
        response = super().send_get_job_status( url= url , payload =payload , headers=headers, verify = False)
        return response 