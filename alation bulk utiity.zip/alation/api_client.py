import requests
from requests.exceptions import HTTPError, Timeout, RequestException
import logging
import time
from os import environ
# Get the logger configured in main.py


BASE_URL = 'https://corteva.alationcloud.com'
# Function to get headers with the API token


class ClassNameFormatter(logging.Formatter):
    def format(self, record):
        # Check if 'class_name' is in the extra dictionary
        if hasattr(record, 'class_name'):
            record.msg = f"[{record.class_name}] - {record.msg}"
        return super().format(record)

class ClassNameLoggerAdapter(logging.LoggerAdapter):
    def __init__(self, logger, class_name):
        super().__init__(logger, {'class_name': class_name})

    def process(self, msg, kwargs):
        # Ensure 'extra' includes 'class_name'
        return f"[{self.extra['class_name']}] - {msg}", kwargs

class RequestExceptionWithResponse(Exception):
    def __init__(self, message, response_text):
        super().__init__(message)
        self.response_text = response_text

    def __str__(self):
        return f"{self.args[0]}\nResponse Text: {self.response_text}"
    
# Custom exception for no data found
class NoDataFoundException(Exception):
    def __init__(self, message="No data found", url=None, method=None, payload=None):
        self.message = message
        self.url = url
        self.method = method
        self.payload = payload
        super().__init__(self.message)

    def __str__(self):
        return (f"{self.message}\n"
                f"URL: {self.url}\n"
                f"Method: {self.method}\n"
                f"Payload: {self.payload}")

class APIClient:
    """
    APIClient class to handle interactions with the Alation API.
    Attributes:

        logger : logging.Logger
            A logger instance for tracking events in the API client.
        base_url : str
            The base URL for the Alation API.
        url : str
            The specific API endpoint to be used for requests (initialized as None).
        api_key : str
            The API key used for authenticating requests.
        headers : dict
            The headers used in all API requests, including the API key for authentication.
    """
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.logger.info("")
        self.base_url = BASE_URL
        self.url = None
        self.api_key = environ['ALATION_API_KEY']
        
        self.headers = {
            "Accept": "application/json",
            "TOKEN": self.api_key,
            "Content-Type": "application/json"
        }
        self.logger = logging.getLogger(__name__)
        self.logger = ClassNameLoggerAdapter(self.logger, self.__class__.__name__)

    def get_headers(self, api_token: str = None) -> dict:
        if api_token:
            return self.__build_headers(api_token)
        elif self.api_key:
            return self.__build_headers(self.api_key)
        else:
            raise ValueError("API token not set")

    def __build_headers(self, token: str) -> dict:
        return {
            'Content-Type': 'application/json',
            'Token': token
        }

    def __send_request(self, method: str, url: str, headers: dict = None, payload: dict = None, verify: bool = False):
        """
        Sends an HTTP request with the specified method to the given URL.

        Parameters:
        
            method : str
                The HTTP method ('GET', 'POST', 'PUT', 'DELETE').
            url : str
                The URL to send the request to.
            headers : dict, optional
                The headers to include in the request.
            payload : dict, optional
                The data to send with the request (for POST, PUT, DELETE).
            verify : bool, optional
                Whether to verify SSL certificates.

        Returns:
        
            response : requests.Response
                The response from the server.

        Raises:
        
            HTTPError
                If an HTTP error occurs.
            RequestException
                If a general request error occurs.
        """
        try:
            if headers is None:
                headers = self.get_headers()

            if method.upper() == 'POST':
                response = requests.post(url, json=payload, headers=headers, verify=verify)
                
            elif method.upper() == 'GET':
                # response = requests.get(url, headers=headers, verify=verify)
                response = requests.get(url, headers=headers, params=payload, verify=verify)
            elif method.upper() == 'PUT':
                response = requests.put(url, json=payload, headers=headers, verify=verify)
            elif method.upper() == 'DEL':
                response = requests.delete(url, json=payload, headers=headers, verify=verify)    
         
            else:
                self.logger.error(f"Unsupported HTTP method: {method}")
                return None

            response.raise_for_status()  # Raises an HTTPError if the response code was unsuccessful
            self.logger.debug(f"{method} request to {url} was successful: {response.status_code}")
            # Check if the response JSON is empty
            try:
                json_response = response.json()
                if not json_response:
                    self.logger.debug("The response JSON is empty")
                    print(self.__class__)
                    raise NoDataFoundException("No data found in the response", url, method, payload)
                    
             
                else:
                    self.logger.debug(f"Response JSON: {json_response}")
            except ValueError:
                self.logger.error("Response is not in JSON format")


            return response
        except HTTPError as http_err:
            
            self.logger.error(f"HTTP error occurred: {http_err} - Response text: {http_err.response.text} {payload}")
            raise RequestExceptionWithResponse(f"HTTP error occurred: {http_err}", http_err.response.text)
        except Timeout as timeout_err:
            self.logger.error(f"Timeout error occurred: {timeout_err}")  # Handle timeout errors
            raise 
        except RequestException as req_err:
            self.logger.error(f"Request exception occurred: {req_err}")  # Handle other request exceptions
            raise
        except Exception as err:
            self.logger.error(f"An unexpected error occurred: {err}")  # Handle any other exceptions
            raise 
        # return None  # Return None if an exception was raised

    def send_post_request(self,  payload: dict, url: str = None, headers: dict = None, verify: bool = True):
        return self.__send_request(method = 'POST'
                                 ,url= self.build_url(url),headers= headers, payload=payload, verify=verify)
    
    def send_put_request(self,  payload: dict, url: str = None, headers: dict = None, verify: bool = True):
        return self.__send_request(method = 'PUT'
                                 ,url= self.build_url(url),headers= headers, payload=payload, verify=verify)

    def send_get_request(self, url: str,  payload: dict= None,headers: dict = None, verify: bool = True):
 
        return self.__send_request(method = 'GET', url = self.build_url(url), payload=payload, headers = headers, verify=verify)
    
    def send_del_request(self, url: str,  payload: dict= None,headers: dict = None, verify: bool = True):
 
        return self.__send_request(method = 'DEL', url = self.build_url(url), payload=payload, headers = headers, verify=verify)
       

    def build_url(self, url:str = None):
        if url:
            full_url = self.base_url + url
        else:
            full_url = self.base_url
        return full_url

    def send_get_job_status(self, url:str, payload:dict, headers: dict = None, verify: bool = False ):
        

        while True:
            response = self.__send_request(method = 'GET', url = self.build_url(url), payload=payload, headers = headers, verify=verify)
            if response.status_code == 200:
                if response:
                    job_status = response.json()
                    if job_status['status'] == 'successful':
                        self.logger.info("Job successful:{} {} for type [{}]".format(payload, job_status, self.__class__.__name__))
                        return job_status  # Exit loop and return the successful job status
                
                    elif job_status['status'] == 'failed':
                        self.logger.error("Job failed:{} {} for type [{}]".format(payload,job_status, self.__class__.__name__))
                        return job_status  # Exit loop and return None if the job fails
                    
                    else:
                        self.logger.info("Job still in progress...{} status: {} for type [{}]".format( payload, job_status['status'], self.__class__.__name__))
                        time.sleep(4)
            
            else:
                return None


    def build_skipped_overwite(self, payload):
        return {'status': 'skipped', 'msg': 'Not overwriting existing item ', "payload": payload}


if __name__ == "__main__":
   api_client = APIClient()
