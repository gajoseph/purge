import logging
from alation.api_client import APIClient  


class AlationTerm(APIClient):
    def __init__(self):
        super().__init__()
        self.url = "/integration/v2/term/"
        self.term_details = {}
        self.title =''
        self.description = ''
        self.template_id= 0
        self.glossary_ids = []
        self.id = 0

    

    
    def __build_payload(self):
        return [
            {
                "title": self.title,
                "description": self.description,
                "template_id": self.template_id,
                "glossary_ids": self.glossary_ids
            }
        ]
    
    def __build_put_payload(self):
        payload = self.__build_payload()
        payload[0]['id'] = self.id
        return payload
    
    def get_job_status(self):
        job_id = self.term_details['job_id']
        job_status_rep = self.send_get_job_status(url = "/api/v1/bulk_metadata/job/", payload= {"id":job_id})
        if "created_terms" in job_status_rep['result']:
            self.id = job_status_rep['result'].get("created_terms" )[0].get("id")
        elif  "updated_terms" in job_status_rep['result']:
            self.id = job_status_rep['result'].get("updated_terms" )[0].get("id")
        return job_status_rep
    

    def __set_properties(self, term_title=None, term_description=None, template_id=None, glossary_ids=[]):
        self.title = term_title if term_title is not None else None
        self.description = term_description if term_description is not None else None
        self.template_id = template_id if template_id is not None else None
        self.glossary_ids = [glossary_ids] if glossary_ids is not None else []
    
    def search_term(self, searh_str_anyfield:str, glossary_id= None):
        payload = {}
        self.term_details ={}
        self.__set_properties()
        try:
            
            if glossary_id:
                payload['glossary_id'] = glossary_id
           
            payload['deleted'] = False
            
            
            if searh_str_anyfield:
                payload['search'] = searh_str_anyfield
            # if deleted is not None:
            #     payload['deleted'] = str(deleted).lower()
            response = self.send_get_request(self.url,  payload=payload, verify=False)
            if response: 
                
                if response.status_code == 200:
                    self.logger.debug(f"{self.__class__} exists: {response}")
                    # Get the Job ID from the response
                    
                    self.term_details = response.json()
                    
                    self.title = self.term_details[0]['title']
                    self.description = self.term_details[0]['description']
                    self.template_id = self.term_details[0]['template_id']
                    self.glossary_ids = self.term_details[0]['glossary_ids']
                    self.id = self.term_details[0]['id']
                
                    self.logger.debug(f"{self.__class__} details: length= {len(self.term_details)}")
                
                        

            else:
                self.logger.error('Failed to retrieve term details.')
                return None
        except Exception as err: 
            self.logger.error(f"Error when processing {payload} {str(err)}")
    
    

    def delete_term(self,term_ids: list ):
        response  = self.send_del_request(self.url, payload={"id":term_ids}, verify = False)
       
        if response .status_code == 200:
            if response :
                return response .json()
                job_id = self.term_details['job_id']
                return self.send_get_job_status(url = "/api/v1/bulk_metadata/job/", payload= {"id":job_id})
            
        else:
            self.logger.error(f"Failed to delete term(s): {response.status_code} {response.text}")
            return None

        

    def create_term(self, term_title,term_description, template_id, glossary_ids):
        self.__set_properties(term_title, term_description, template_id, glossary_ids)
        payload = self.__build_payload()
        
        response = self.send_post_request(url = self.url, payload= payload, verify=False)
        #  Check the response
        if response and response.status_code == 202:
            self.term_details = response.json()
            self.logger.info(f'{self.__class__.__name__} Created:{self.term_details}')
            return self.get_job_status()
            
        else:
            self.logger.error('Failed: %s, %s', response.status_code, response.text)
            return None
    

    
    def update_terms(self, term_title= None, term_description= None, template_id= None, glossary_ids = None, overwrite= False):
        self.__set_properties( term_title, term_description, template_id, glossary_ids)
        payload = self.__build_put_payload()
        if not overwrite:
            return self.build_skipped_overwite(payload=payload)

        try:
        
            response = self.send_put_request(url = self.url, payload= payload, verify=False)
            # Check the response
            if response and response.status_code == 202:
                
                self.term_details = response.json()
                self.logger.info(f'Documents updated:{self.term_details}')
                
                return self.get_job_status()
            else:
                self.logger.error(f'Failed to update term: {response.status_code}, {response.text}')
                return None
        except Exception as err:
            self.logger.error(f"An unexpected error occurred: {err}")  # Handle any other exceptions
        

    # def create_term( headers, term_title,term_description, template_id, glossary_id  ):
    
    #     # search for the term by name in case it already exists, if more than one is found do not update
        
    #     parm = 'limit=100&skip=0&search=%s&deleted=false' % term_title
    #     response = requests.get(BASE_URL + term_url, params=parm, headers=headers, verify= False )
    #     term_found = response.json()

    #     print(term_found)

    #     if len(term_found) == 0:
    #         # create term with temp name
    #         term_url = '/integration/v2/term/'

    #         payload = [
    #             {
    #                 "title": term_title,
    #                 "description": term_description,
    #                 # "template_id": template_id,
    #                 "glossary_ids": ["13"],
    #             }
    #         ]
    #         response = requests.post(BASE_URL + term_url, json=payload, headers=headers, verify= False)
    #         term_result = response.json()
    #         print(term_result)
    #         exit()
    #         term_id = term_result['job_id']

    #         print('Term %s created' % term_title)