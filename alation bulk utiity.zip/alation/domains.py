import json
import requests
import alation.api_client as cm

from alation.api_client import APIClient  


class AlationDomain(APIClient):
    def __init__(self, domain_id):
        super().__init__()
        self.url = "/integration/v2/domain/"
        self.domain_details = {}
        self.title =''
        self.description = ''
        self.glossary_ids = []
        self.id = domain_id


    def get_job_status(self):
        job_id = self.domain_details['job_id']
        job_status_rep = self.send_get_job_status(url = "/api/v1/bulk_metadata/job/", payload= {"id":job_id})
        if "created_terms" in job_status_rep['result']:
            self.id = job_status_rep['result'].get("created_terms" )[0].get("id")
        elif  "updated_terms" in job_status_rep['result']:
            self.id = job_status_rep['result'].get("updated_terms" )[0].get("id")
        return job_status_rep
        
    def add_members(self, oids:list, otype:str ):
        url = "/integration/v2/domain/membership/"

        payload = {
                "oid": oids,
                "otype": f"{otype}",
                "id": self.id
            }
        response = self.send_post_request(url = url,  payload=payload, verify=False)
        if response: 
                    
            if response.status_code == 201:
                self.logger.info(f"{self.__class__.__name__} membership : {response}")
                return response
            elif response.status_code == 202:
                self.logger.info(f"{self.__class__.__name__} exists: {response}")
                self.domain_details = response.json()
                self.logger.info(f'{self.__class__.__name__} Created:{self.domain_details}')
                return self.get_job_status()

    



def add_domain_member(headers, domain_id, oids, otype):
    
    url = "/integration/v2/domain/membership/"

    payload = {
            "oid": oids,
            "otype": f"{otype}",
            "id": domain_id
        }

    print(payload, cm.BASE_URL + url , headers)
    response = requests.post(cm.BASE_URL + url, json=payload, headers=headers, verify=False)

    print("gerge", response.text, response.status_code)


# # def get_otypes

# domain_id, oids of term, 


# given a domain name 
# 1. get the domain ID 




# acrynom is created 