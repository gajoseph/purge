# Create a new virtual environment in the .venv directory
python3 -m venv .venv

# Activate the virtual environment (on Windows)
source .\venv\Scripts\activate

# Clone the repository from Azure DevOps
git clone https://vs-pioneer@dev.azure.com/vs-pioneer/project0/_git/Enterprise-Alation-CustomCode

# Pull the latest changes from the remote repository
git pull 

# Switch to the specific branch you want to work on
git checkout {branch}

# Install the packages from the requirements.txt file
pip install -r requirements.txt

# Run the main Python script to load the terms GSO
# see ## Running the Script in bulk_loader.md
python ./main.py
