import logging
import sys 
import os 
import getpass
import time
import warnings
from  datetime import datetime
import alation.api_client as ap 
def setLoggingInfo(__log_prop_dict):
    """
    __log_prop_dict: dict w/ log info
    private method
    """
    logFile = (f"{__log_prop_dict['log.file.path']}/"
            f"{__log_prop_dict['name']}_"
            f"{os.path.splitext(os.path.basename(sys.argv[0]))[0]}_"
            f"{getpass.getuser()}_"
            f"{time.strftime('%Y%m%d%H%M%S')}.log"
    )


    """
    LOGGING SETTINGS
    """
    logging.basicConfig(
        filename=logFile
        , level=logging.INFO
        , format=__log_prop_dict["log.format"]
        , datefmt=__log_prop_dict["log.date.format"]
    )

    root = logging.getLogger()
    ch = logging.StreamHandler(sys.stdout)
    # Suppress warnings
    warnings.filterwarnings("ignore", module="urllib3.connectionpool")

    # Suppress logs
    logging.getLogger("urllib3").setLevel(logging.CRITICAL)
    ch.setLevel(logging.DEBUG)
    # ch.setLevel(logging.ERROR)
    # formatter = logging.Formatter(__log_prop_dict["log.format"], datefmt=__log_prop_dict["log.date.format"])
    formatter = ap.ClassNameFormatter(__log_prop_dict["log.format"], __log_prop_dict["log.date.format"])

    ch.setFormatter(formatter)
    root.addHandler(ch)
    logging.info("Init log")


def generate_report_file_path(config):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    out_folder = os.path.join(base_dir, config['alation.report.folder.name'])
    os.makedirs(out_folder, exist_ok=True)
    report_file_name = os.path.join(out_folder, config['alation.report.file.name'].format(timestamp))
    return report_file_name