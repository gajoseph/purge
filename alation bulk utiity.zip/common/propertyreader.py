import configparser
from collections import Counter
from yaml import safe_load
from os import environ
import os 

config = configparser.RawConfigParser(delimiters = ":")


def get_yaml_properties(file_name:str):
    print(file_name)
    with open(file_name, "r") as config_stream:
        config = safe_load(config_stream)
        
 
    config['app']['log.file.path'] = os.path.join(os.getcwd(),config['app']['log.file.path'])
    os.makedirs(config['app']['log.file.path'], exist_ok=True)
    
    
    
    return config['app']