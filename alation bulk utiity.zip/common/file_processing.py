import json
import csv
import logging
logger = logging.getLogger(__name__)

def get_objecttype_data(data, object_type):
  """Retrieves data for a specific object type from a JSON array.
  Args:
    data: The JSON data as a list of objects.
    object_type: The desired object type.
  Returns:
    A list of objects with the specified object type, or an empty list if not found.
  """
  return [item for item in data if item['type'] == object_type]

def get_acronym_data(data):
  """Retrieves Acronym data from the JSON array.
  Returns:
    A list of Acronym objects.
  """

  return get_objecttype_data(data, 'acronym')

def get_term_data(data):
  """Retrieves Term data from the JSON array.
  Args:
    data: The JSON data as a list of objects.
  Returns:
    A list of Term objects.
  """

  return get_objecttype_data(data, 'terms')



def convert_template_id(template_id):
  

  try:
    return int(template_id.strip())
  except ValueError:
    logger.error(f"Invalid template_id format: {template_id}")
    return None  # Or handle the error differently
  


def convert_folder_id(folder_id):
  

  try:
    return int(folder_id.strip())
  except ValueError:
    logger.error(f"Invalid folder_id format: {folder_id}")
    return None  # Or handle the error differently
  


def convert_folder_ids(folder_id):
  """Converts a comma-separated string of folder IDs to a list of integers.

  Args:
    folder_id: A string representing comma-separated folder IDs.

  Returns:
    A list of integers representing the folder IDs, or an empty list if there's an error.
  """

  try:
      return [int(id) for id in folder_id.strip().split(",")]
  except ValueError:
      logger.error(f"Invalid folder_id format: {folder_id}")
      return []

def read_file_in_batches(file_path, batch_size):
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        header = next(reader)  # Skip the header
        
        header_list = [h.strip() for h in header]
        while True:
            lines = []
            for _ in range(batch_size):
                try:
                    line = next(reader)
                    if len(line) != len(header):
                        logger.error(f"Skipping line due to unexpected number of columns or empty line: {line}")
                        continue
                    lines.append(line)
                except StopIteration:
                    break
            if not lines:
                break
            yield lines, ','.join(header_list)



def process_data_list(data_list):

    json_data_list = []
    for values in data_list:
        title, description, document_hub_id, otype, folder_id, folder_name, template_id, template_name, domain_id = values
        
        template_id = convert_template_id(template_id)
        if otype.strip().lower() == 'acronym':
            folder_id = convert_folder_id(folder_id)
            json_obj = {
                        "title": title.strip(),
                        "description": description.strip(),
                        "document_hub_id": int(document_hub_id.strip()),
                        "folder_ids": folder_id,
                        "template_id": template_id 
                    }
              
        elif otype.strip().lower() == 'glossary_term':
            # Create a JSON object for glossary term here
            glossary_id = convert_folder_id(folder_id)
            json_obj =  {
                        "title": title.strip(),
                        "description": description.strip(),
                        "glossary_ids": glossary_id, # check how ptocess if there is comma separetd fields 
                        "template_id": template_id 
                    }
                
        json_obj["domain_id"] = domain_id
            # Find or create a JSON object for the current object type
        found_obj = next((item for item in json_data_list if item['type'] == otype.strip().lower()), None)
        if found_obj:
            found_obj['data'].append(json_obj)    
        else:
            json_data_list.append({"type": otype.strip().lower(), "data": [json_obj]})
        # json_data_list.append(json_obj)
    return json_data_list




def read_file_and_build_json_in_batches(file_path, batch_size):
    all_json_objects = []
    header = ""
    for lines, _header in read_file_in_batches(file_path, batch_size):
        json_objects = process_data_list(lines)
        all_json_objects.append(json_objects)
        header = _header
    return all_json_objects, header


