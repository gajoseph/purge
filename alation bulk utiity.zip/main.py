import csv
import os
import logging
import warnings
from os import environ
from datetime import datetime

import common.propertyreader as pr
import common.utils as ut
import alation.documents as ad
import common.file_processing as fp

import alation.terms as at

import alation.domains as adom

def init_data_row_status():
    data_row_status = {
        'insert': {},
        'update': {},
        'dupsdeleted': {},
        'add_mem_domain': {}
    }
    return data_row_status


def write_to_report(batch, data_row:dict , header:str, writer: csv.writer, data_row_status:dict):
     # Prepare the row to write
    row_to_write = [batch]  # Start with the batch number
    l_data_row = data_row
    l_data_row.update(data_row_status)
    header +=    "," + ",".join(data_row_status.keys())

    print(header)
    for key in header.split(','):
        if key != "batch":
            value = l_data_row.get(key, '')
            if value == '' or value == {}:
                value = 'N/A'  # Replace with a default value, e.g., 'N/A'
            row_to_write.append(value)  # Add value corresponding to each header key

    # Write the row to the CSV file
    writer.writerow(row_to_write)
    writer


def process_acronym(batch, batch_json_object, doc_object: ad.DocumentClient, csv_writer: csv.writer =None, csv_header =None, overwrite=False):
    logger = logging.getLogger()
    logger.info(f"Processing batch {batch}: Type={batch_json_object['type']}")
    logger.debug(f"Data={batch_json_object['data']}")

    alation_doc_id = []
     
    if batch_json_object['type']== 'acronym':
        for data in batch_json_object['data']:
            doc_ids = []
            domain_id = 0
            
            data_row_status = init_data_row_status()
            logger.debug(f"Processing document: {data}")
           
            # Search for existing documents
            doc_object.search_documents(
                searh_str_anyfield=data['title'],
                document_hub_id=data['document_hub_id'],
                folder_id=data['folder_ids']
            )

            
            for item in doc_object.document_details:
                if data['title'] == item['title']:
                    doc_ids.append(int(item["id"]))
                    doc_object.id = int(item["id"])
                    if len(doc_object.document_details) > 1:
                        logger.info(f"Duplicate match from Alation API for: {data['title']} will be EXACT match on title")
                    elif len(doc_object.document_details)  == 1 or len(doc_ids) == 1: # we got onlye one row back from api and check the title 
                        logger.info("Single match foudn from Alation API")
            domain_id= int(data['domain_id'])

            # Insert, update, or delete and insert based on the document search results
            if not doc_ids:
                logger.info("Inserting new document")
                crt_response = doc_object.create_document(document_title = data['title']
                                                          , document_description= data['description']
                                                          , template_id = data['template_id']
                                                          , folder_ids = data['folder_ids']
                                                          , document_hub_id = data['document_hub_id'])
                data_row_status["insert"] = crt_response
                logger.info(f"Insert response: {crt_response}")
            elif len(doc_ids) == 1:
                logger.info("Updating existing document")
                upd_response = doc_object.update_document(document_title = data['title']
                                                          , document_description= data['description']
                                                          , template_id = data['template_id']
                                                          , folder_ids = data['folder_ids']
                                                          , document_hub_id = data['document_hub_id']
                                                          , overwrite = overwrite)
                logger.info(f"Update response: {upd_response}")
                
                data_row_status["update"] = upd_response
            else:
                logger.info("Deleting dups and inserting document")
                logger.debug(f"Document IDs to delete: {doc_ids}")
                del_response = doc_object.delete_document(doc_ids)
                data_row_status = {"dupsdeleted":del_response}
                crt_response = doc_object.create_document(document_title = data['title']
                                                          , document_description= data['description']
                                                          , template_id = data['template_id']
                                                          , folder_ids = data['folder_ids']
                                                          , document_hub_id = data['document_hub_id'])
                data_row_status["insert"]= crt_response
                logger.info(f"Re-insert response: {crt_response}")
            logger.info("Add to domain docuemnd id [%s]", doc_object.id)
            alation_doc_id.append(doc_object.id)
            if domain_id > 0:
                add_mem_response =  assign_domain(domain_id, doc_object.id, 'glossary_term')
                data_row_status["add_mem_domain"] = add_mem_response
            write_to_report(batch, data_row = data, header = csv_header, writer = csv_writer, data_row_status = data_row_status)
    return alation_doc_id



def process_term(batch, batch_json_object, term_object: at.AlationTerm, csv_writer: csv.writer =None, csv_header =None, overwrite=False):
    logger = logging.getLogger()
    logger.info(f"Processing batch {batch}: Type={batch_json_object['type']}")
    logger.debug(f"Data={batch_json_object['data']}")

    alation_doc_id = []
     
    if batch_json_object['type']== 'glossary_term':
        for data in batch_json_object['data']:
            term_ids = []
            domain_id = 0
            logger.debug(f"Processing %s: %s", batch_json_object['type'], data )
            data_row_status = init_data_row_status()
            # Search for existing documents
            term_object.search_term(
                searh_str_anyfield=data['title'],
                glossary_id=data['glossary_ids']            )

            
            for item in term_object.term_details:
                if data['title'] == item['title']:
                    term_ids.append(int(item["id"]))
                    term_object.id = int(item["id"])
                    if len(term_object.term_details) > 1:
                        logger.info(f"Duplicate match from Alation API for: {data['title']} will be EXACT match on title")
                    elif len(term_object.term_details)  == 1 or len(term_ids) ==1: # we got onlye one row back from api and check the title 
                        logger.info("Single match foudn from Alation API")
            domain_id= int(data['domain_id'])

            # Insert, update, or delete and insert based on the document search results
            if not term_ids:
                logger.info("Inserting new term")
                # term_title,term_description, template_id, glossary_ids
                crt_response = term_object.create_term(term_title = data['title']
                                                       , term_description= data['description']
                                                       , template_id= data['template_id']
                                                       , glossary_ids=data['glossary_ids'])
                data_row_status["insert"] = crt_response
                logger.info(f"Insert response: {crt_response}")
            elif len(term_ids) == 1:
                
                upd_response = term_object.update_terms(term_title = data['title']
                                                        , term_description = data['description']
                                                        , template_id = data['template_id']
                                                        , glossary_ids = data['glossary_ids']
                                                        , overwrite=overwrite)
                data_row_status["update"] = upd_response
                logger.info(f"Update response: {upd_response}")
            else:
                logger.info("Deleting dups and inserting term")
                logger.debug(f"TErm IDs to delete: {term_ids}")
                del_response = term_object.delete_term(term_ids)
                data_row_status = {"dupsdeleted":del_response}
                crt_response = term_object.create_term(term_title = data['title']
                                                       , term_description = data['description']
                                                       , template_id = data['template_id']
                                                       , glossary_ids = data['glossary_ids'])
                data_row_status["insert"] = crt_response
                logger.info(f"reinsert response: {crt_response}")
            logger.info("Add to domain %s these terms id [%s]", domain_id, term_object.id)
            alation_doc_id.append(term_object.id)
            if domain_id > 0:
                add_mem_respone = assign_domain(domain_id, term_object.id, 'glossary_term')
                data_row_status["add_mem_domain"] = add_mem_respone
                
            write_to_report(batch, data_row= data, header = csv_header, writer=csv_writer, data_row_status= data_row_status)
    return alation_doc_id


def assign_domain(domain_id:int, child_id:int, os_type:str):
    logger = logging.getLogger()
    dom_obj:adom.AlationDomain = adom.AlationDomain(domain_id)
    add_mem_response = dom_obj.add_members([child_id], os_type)
    logger.info(f"Add domain member response: {add_mem_response.text}")
    return add_mem_response.json()



def main():
    # Load configuration and set up logging
    config = pr.get_yaml_properties(environ['ENV_YAML_PATH'])
    alation_asset_exist_action = config["alation.asset.exist.action"]
    ut.setLoggingInfo(config)

    logger = logging.getLogger(__name__)
    logger.info("Starting document processing")

    # Define file path and ensure it exists
    file_path = os.path.join(os.path.dirname(__file__), config['alation.csv_input'])

    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"The file {file_path} does not exist.")
    
    report_file_name = ut.generate_report_file_path(config)
    print(report_file_name)

    # Process the file in batches
    batch_size = config['alation.load.batch.size']
    json_list, header_csv = fp.read_file_and_build_json_in_batches(file_path, batch_size)
    doc_object = ad.DocumentClient()
    term_obj = at.AlationTerm()
    
    header_csv = "batch," + header_csv + "," + ",".join(init_data_row_status().keys())
   
    with open(report_file_name, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        
        # Optionally write header row
        writer.writerow(header_csv.split(','))
        # Process each batch
        for batch, batch_json_object in enumerate(json_list):
            logger.info("Processing batch [%s], size: [%s]", batch, len(batch_json_object[0]["data"]))

            for idex, item in enumerate(batch_json_object):
                if item['type']== 'acronym':
                    alation_document_ids:list = process_acronym(batch, item, doc_object, writer, header_csv, overwrite= (alation_asset_exist_action == "upsert"))
                    print(alation_document_ids)
                elif item['type']== 'glossary_term':
                    logger.info("%s, dfdsffds %s", item['type'], item)
                    alation_term_ids:list = process_term(batch, item, term_obj, writer, header_csv, overwrite= (alation_asset_exist_action == "upsert"))
                    print(alation_term_ids)

    

        
        

if __name__ == "__main__":
    main()
