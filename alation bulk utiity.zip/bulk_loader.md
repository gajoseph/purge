[[_TOC_]]

# Alation Load Script - Technical README

## Overview

This script is developed to process CSV file data in batches, connect with the Alation platform via API, and load `acronyms` and `glossary terms` into Alation. The configuration parameters are loaded from a YAML file, which dictates how the script operates—including file paths, batch sizes, API endpoints, and logging settings.

## Prerequisites

- **Python Version**: Ensure that you are using Python 3.6 or above.
    - See [install Python](./readme.md#guide-to-setting-up-on-your-system) and [virtual environment setup](./readme.md#set-up-a-virtual-environment).
- **Required Libraries**:
   Listed in `requirements.txt`.
   Install required libraries using:
   ```bash
   pip install -r requirements.txt
   ```

## Configuration File

The script relies on a YAML configuration file defined by the `ENV_YAML_PATH` environment variable. Below is an example of the expected structure of the configuration file:
`config\config.yml`

### Key Configuration Parameters:

- **Logging Settings**:
  - `log.level`: The logging level (e.g., `info`, `debug`).
  - `log.format`: The format of the log messages.
  - `log.date.format`: The date format used in log messages.
  - `log.file.path`: The directory where log files will be stored.

- **File Paths**:
  - `alation.csv_input`: The name of the CSV input file.
  - `alation.report.file.name`: The naming pattern for the report file, with `{}` as a placeholder for a timestamp.
  - `alation.report.folder.name`: The directory where the report file will be saved.

- **Batch Processing**:
  - `alation.load.batch.size`: The number of records to process in each batch.

- **Asset Management**:
  - `alation.asset.exist.action`: Determines how to handle existing assets (`upsert` or `insert`).

- **Alation API Endpoints**:
  - The various API endpoints required for interacting with Alation, such as `alation.api.documents`, `alation.api.domains`, and others.

## Script Breakdown

### 1. Loading Configuration

The configuration is loaded from the YAML file specified by the `ENV_YAML_PATH` environment variable:
```python
config = pr.get_yaml_properties(environ['ENV_YAML_PATH'])
alation_asset_exist_action = config["app"]["alation.asset.exist.action"]
```

### 2. Logging Setup

Logging is initialized based on settings provided in the configuration:
```python
ut.setLoggingInfo(config)
logger = logging.getLogger(__name__)
logger.info("Starting document processing")
```

### 3. File Path Validation

The script ensures that the specified CSV input file exists:
```python
file_path = os.path.join(os.path.dirname(__file__), config['app']['alation.csv_input'])

if not os.path.isfile(file_path):
    raise FileNotFoundError(f"The file {file_path} does not exist.")
```

### 4. Generate Report File Path

The script generates the report file path using a utility function:
```python
report_file_name = ut.generate_report_file_path(config)
```

### 5. Batch Processing

The script processes the input file in batches, reading the file, generating JSON data, and logging the operations:
```python
batch_size = config['app']['alation.load.batch.size']
json_list, header_csv = fp.read_file_and_build_json_in_batches(file_path, batch_size)
```

### 6. Header Preparation

The script prepares the CSV header:
```python
header_csv = "batch," + header_csv + "," + ",".join(init_data_row_status().keys())
```

### 7. CSV File Writing

The script writes the processing log to a CSV file:
```python
with open(report_file_name, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(header_csv.split(','))
```

### 8. Document and Term Processing

The script processes each batch for acronyms and glossary terms, updating or inserting them into Alation based on the configuration `alation.asset.exist.action`:

```python
for batch, batch_json_object in enumerate(json_list):
    logger.info("Processing batch [%s], size: [%s]", batch, len(batch_json_object[0]["data"]))

    for index, item in enumerate(batch_json_object):
        if item['type'] == 'acronym':
            alation_document_ids = process_acronym(batch, item, doc_object, writer, header_csv, overwrite=(alation_asset_exist_action == "upsert"))
            print(alation_document_ids)
        elif item['type'] == 'glossary_term':
            logger.info("%s, dfdsffds %s", item['type'], item)
            alation_term_ids = process_term(batch, item, term_obj, writer, header_csv, overwrite=(alation_asset_exist_action == "upsert"))
            print(alation_term_ids)
```

### 9. Supporting Functions

- **`init_data_row_status()`**: Initializes the status of data rows.
- **`write_to_report(batch, data_row, header, writer, data_row_status)`**: Writes data rows to the CSV report.
- **`process_acronym(batch, batch_json_object, doc_object, csv_writer, csv_header, overwrite)`**: Processes acronyms and loads them into Alation.
- **`process_term(batch, batch_json_object, term_object, csv_writer, csv_header, overwrite)`**: Processes glossary terms and loads them into Alation.
    - Search
    - Update/insert 
- **`assign_domain(domain_id, child_id, os_type)`**: Assigns terms or documents to a domain in Alation.

## Running the Script

### 1. Set the Environment Variable

Ensure that `ENV_YAML_PATH` is set to the path of your YAML configuration file:
```bash
export ENV_YAML_PATH=config\config.yml # Linux 
set ENV_YAML_PATH=config\config.yml # Windows
set ALATION_API_KEY="XXX-XXXnsflkdhflkdshjfhdsfhsfhsdlfhl"
.\.venv\Scriptsctivate
```

### 2. Run the Script

Execute the script:
```bash
python .\main.py
```

## Error Handling

- **FileNotFoundError**: Raised if the specified CSV file does not exist in the expected location.
- **Logging**: Logs are generated to track the progress and any issues encountered during processing.

## Customization

- **Batch Size**: Modify the `alation.load.batch.size` in the YAML file to change the number of records processed per batch.
- **File Paths**: Update the `alation.csv_input` and `alation.report.file.name` in the YAML file to change the input and output file names.

---
